#! /bin/bash

Rscript -e 'jlimR:::run.jlim()' ARGSTART $* 
